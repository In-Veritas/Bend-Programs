# Leiden (stub; replaced below)
import Base
import ./f64.bend as F
import ./cl_graph.bend as G

def leiden(rows: Array<List<&2, G.Nb>>, +n: U32, +m: U32, +res: F.D, +beta: F.D, +iters: U32, +ineg: Bool) -> Array<U32> & U32:
  (G.u32_array(n, 0), 1)
