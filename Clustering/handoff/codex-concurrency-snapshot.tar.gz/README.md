# Vclust em Bend

Porte nativo das três etapas do Vclust 1.3.1: pré-filtro Kmer-db 2.3.1,
alinhamento LZ-ANI 1.2.3 e seis algoritmos do Clusty 1.2.2. O cálculo das
etapas está em Bend; Python compila, limita memória, executa e verifica a
saída de clustering. Este pacote é separado do frontend antigo `../run.py`.

## Executar

Requisitos: Linux com systemd de usuário, Python 3.11+, compilador Bend
2.0.40 e compilador C disponíveis. Revisão testada do checkout fonte:
`6b806192284fc9c64404d9b0b59c937f568d87ec`. Não é necessário usar o antigo
scratchpad `/tmp` para executar o pipeline. Na máquina desta retomada:

```bash
cd /home/veritas/Bend-Programs/Clustering/vclust_bend
export BEND_REPO='/home/veritas/Bioinformatique/Higher Order Company/Bend'
mkdir -p results
python3 run.py prefilter -i ../datasets/public_viromes/original/vclust_example.fasta -o results/filter.txt -t 12
python3 run.py align -i ../datasets/public_viromes/original/vclust_example.fasta --filter results/filter.txt -o results/ani.tsv -t 12
python3 run.py cluster -i results/ani.tsv --ids results/ani.ids.tsv -o results/clusters.tsv --algorithm leiden --metric ani --ani 0.95 -t 1
```

`align` também escreve `ani.ids.tsv`. `cluster` publica o TSV depois de
validar seu contrato semântico e grava `clusters.tsv.certificate.json`, com
hashes dos inputs/saída, parâmetros e testemunha de conectividade. O par de
arquivos não constitui uma transação única; compare o hash de saída do
certificado ao TSV ao consumi-los. Identificadores duplicados são recusados
pelo verificador por tornarem o mapeamento ambíguo.

O launcher usa cache em `.work/bin/` com hash dos fontes e compilador.
Uma trava serializa builds concorrentes e o executável só entra no cache
depois de terminar a compilação.
`--build-only` imprime o executável. `--compiler CAMINHO` substitui
`BEND_REPO`. `-t N` controla os workers Bend por `+RTS --threads N -RTS`;
passar `-t` diretamente ao binário não configura o runtime.

Os processos ficam em `bendwork.slice` (limite agregado 10 GiB, pressão a
9 GiB, sem swap); compilação até 8 GiB, execução até 3 GiB por padrão.
`--memory 4G` altera o limite do processo, mantendo o teto agregado. O
sandbox do Codex precisa autorizar o acesso ao systemd de usuário. Evitar
compilações e benchmarks simultâneos.

## O que as provas garantem

| Evidência | Contrato e limite |
| --- | --- |
| `partition_certificate.bend`, BendTT `--verdict` | Para qualquer lista aceita, há exatamente uma atribuição por posição ativa e todo rótulo é menor que o limite. O certificado é conferido antes de renderizar a saída nativa. Não exige que todos os rótulos possíveis sejam usados. |
| `clique_certificate.bend`, BendTT `--verdict` | Aceitar implica que cada par distinto com mesmo rótulo tem aresta no grafo fornecido. O modo `complete` usa uma cópia do grafo filtrado anterior ao agrupamento. |
| `proofs/Forest.lean`, Lean 4.34.0 | Arestas de pais, raiz preservada e rank estritamente decrescente implicam caminhos à raiz. Com fechamento das arestas, igualdade de raízes equivale a pertencer ao mesmo componente conexo. |
| `tests/verify_clusters.py`, a cada execução do launcher | Confere todos os identificadores exatamente uma vez, constrói/confere uma floresta; exige componentes exatos em `single`, clique em `complete`, centro adjacente a todos em `uclust`/`cd-hit`/`set-cover`, e conectividade em `leiden`. |
| Comparação byte a byte | Exercita a compatibilidade com Vclust nos casos registrados; não é prova universal de equivalência. |

O parser e o verificador Python permanecem na base de confiança: o teorema
Lean prova a implicação matemática a partir das hipóteses verificadas, não
a implementação de Python. Extração dos arrays, IO, renderização, compilador
e runtime também não foram provados de ponta a ponta. Os contratos referem-se
ao **grafo filtrado recebido**, não demonstram ausência de falsos negativos
no pré-filtro, validade biológica do limiar ANI, equivalência numérica
universal do alinhador nem ótimo global de Leiden. `--check-only` verifica
tipos/terminação; o veredicto matemático é `--verdict`.

## Validar e comparar

O Vclust de referência está em `../.tools/vclust-1.3.1/bin/vclust`.
Dados ficam em `../datasets/`. As referências usadas foram copiadas para
`.work/references/`, com hashes em `evidence/reference-inputs.json`.
Os testes regeneram referências ausentes com Vclust; não dependem da
sobrevivência do antigo `/tmp`. Executar sequencialmente:

```bash
python3 tools/validate.py check
python3 tools/validate.py proofs
python3 tools/validate.py guards
python3 tools/validate.py cli-tests
python3 tools/validate.py prefilter-tests --full
python3 tools/validate.py align-tests --full --threads 12
python3 tools/validate.py cluster-tests --full
python3 tools/validate.py semantics
python3 tools/validate.py benchmark --threads 1
python3 tools/validate.py benchmark --full --threads 12
python3 tools/validate.py certified-timings
```

`proofs` precisa de Lean 4.34.0 em PATH ou na instalação local registrada
no script. `guards` injeta atribuições/cliques inválidos na função de produção
e testa TSVs adversariais. Os JSONs em `evidence/` registram as execuções
concluídas; `.work/` contém executáveis, saídas e logs intermediários.
O benchmark faz uma amostra sequencial por ferramenta/configuração, com
1 e 12 workers na amostra de 1000 genomas e 12 no conjunto completo,
com comparação das quatro saídas. Os comandos acima geram JSONs separados. Exclui
compilação, launcher Bend e verificador Python das medidas; inclui os guardas
nativos. O tempo Vclust inclui seu CLI Python oficial. `certified-timings`
mede separadamente o comando de cluster com toda a verificação adicional.
Não interpretar uma amostra em desktop como resultado estatístico.

## Escopo e limitações operacionais

- Algoritmos: `single`, `complete`, `uclust`, `cd-hit`, `set-cover`, `leiden`.
  Leiden reproduz PCG32, ordem de somas binary64, desempates, refinamento,
  agregação e projeção do igraph usado pelo Clusty. Não usa Python para calcular
  os grupos. `tests/clusty_model.py` é referência de testes e parser numérico.
- LZ-ANI aceita `1 <= mal <= 16`, `1 <= msl <= 12`, `1 <= aw <= 32`.
  Há validação explícita dos parâmetros suportados; não prometer todos os
  recursos/formats do CLI Vclust (por exemplo diretórios/gzip).
- O leitor de métricas aceita decimais não negativos com limites declarados
  de tamanho; notação exponencial não é suportada. O formato emitido pelo
  alinhador testado está dentro desse domínio.
- Leiden: beta positivo; no máximo 1000 iterações positivas; iterações negativas
  preservam a semântica da versão de igraph empacotada com teto de segurança.
  Limites internos de fila/sorteio/níveis recusam saída ao esgotar o orçamento.
- A checagem nativa de clique é quadrática em pares de vértices, além da busca
  de vizinhança. É um custo de certificação de `complete`, não uma otimização.
- O caso `prefilter -k 30 --min-ident 0.9` não entra no total aprovado:
  Kmer-db de referência travou no exemplo e foi interrompido após 30 s.
  `tests/test_prefilter.py --include-slow-reference` permite tentar novamente
  com timeout; não foi atribuído como bug do Bend.

## Continuidade

Leia `../CLAUDE_HANDOFF.md` e `CLAUDE_HANDOFF.md` antes de retomar.
A fonte herdada está preservada em `../handoff/`; fontes e evidências da
apresentação estão em `../presentation/`. Nada foi commitado ou publicado
por esta retomada.

## Stage align (LZ-ANI 1.2.3 as driven by `vclust align`)

Sources: `align.bend` (CLI, FASTA/filter streaming, ordering, pairs, work
units, fork-join, output), `align_lz.bend` (CParser port), `align_io.bend`
(byte-level FASTA and Kmer-db filter parsers), `align_num.bend` (exact
numerics). `python3 run.py align -i X -o ani.tsv --filter fltr.txt -t N ...`;
flags as in `vclust align`: `--filter-threshold`, `--outfmt lite|standard|complete`,
`--out-ani/--out-tani/--out-gani/--out-qcov/--out-rcov`, `--mal --msl --mrd --mqd
--reg --aw --am --ar`. Without `--filter` every pair is aligned (as Vclust).

What is reproduced (sources read: LZ-ANI v1.2.3 `src/`, vclust v1.3.1):

- Input: `load_multifasta` (name up to the first space, `\r\n`, empty lines,
  empty headers dropped, non-ACGT = N, an unterminated last line is ignored
  like refresh `getline`). Sorting `reorder_items` (length - 2 as uint32
  descending, then name). Filter: `CFilter::load_filter` (rows = lines longer
  than 2 bytes, `j:value` entries, `value >= threshold`, both directions,
  names must equal the FASTA names).
- Parse: `prepare_reference` (forward, 2*mrd N, reverse complement, mrd N),
  `prepare_data`, the long-anchor table (all positions with the same 11-mer,
  longest wins, first position on ties; anchor at position 0 ignored), the
  close-seed table with `lower_bound` and the nearest-position tie rule,
  `compare_ranges`, `compare_ranges_both_ways` (including its data-position
  quirk when merging), forward/backward approximate extension, region removal,
  `calc_stats`. Factors live on an array stack exactly as `v_parsing`.
- The close/distant choice `ipow(1 - 4^-len, n)` is evaluated with an exact
  software binary64 multiply (`Dbl`, round-half-even on 53-bit mantissas), not
  F32: anchor probabilities are tabulated per work unit, close probabilities
  once per run. Checked against Python floats on 400 random (len, n) cases.
- Output: same row order (pairs a < b in sorted order; row (q=b, r=a) then
  (q=a, r=b)), header per `--outfmt`, `ani.ids.tsv` path rule. Ratios are
  printed from the exact rational a/b with the result of
  `refresh::real_to_pchar(double(a)/b, 6)` (dragonbox shortest + round half up
  to 6 significant digits, `1.00000`, `e-05` forms; 4 digits for len_ratio).
  This equals the binary64 path whenever the denominator is < 4.29e8 (proof
  sketch in `align_num.bend`; 3000 random ratios checked against Python).
  Thresholds are compared exactly as rationals against ceil(t * 10^9), which
  equals the binary64 comparison for thresholds with <= 9 decimals.

Parallelism and memory: each reference row is cut into work units (the
reference plus a chunk of partners, about total/(16*threads) cost each); a
balanced binary fork-join tree over the units runs them. A unit owns one
`Array<U32>` with every region (reference + both k-mer tables + query +
query k-mers + factor stack); only the references of running units are
resident. Sequences are shared read-only as 2-bit packed Data (`Seq`,
borrowed reads, no `@unsafe`). Two performance lessons: a Data record of 24
U32 fields is passed unboxed (24 words per call); adding one boxed field
(`Ctx.box`) made the parser 1.8x faster. And `when`-style lambda matches on
the per-position path cost a closure apply each; the hot path uses
Bool-parameter helper defs instead.

Not supported (explicit errors or documented differences): directory input
(multi-part genomes, `no_parts > 1`: Bend Base cannot list a directory; every
record is one part), gzip input, `--out-aln`, `mal > 16`, `msl > 12`,
`aw > 32`; binary64 underflow to subnormals in the probability test is not
emulated (needs non-default `msl` below about 13 with negative exponents);
upstream reads before the reference start when a final unaligned tail follows
a match ending within the first `msl` reference symbols (undefined behaviour
in C++; not reproduced).

Equivalence (byte-identical `ani.tsv` and `ani.ids.tsv`, so every column's
max |diff| is 0): see `tests/test_align.py` (launcher-based suite, JSON in
`evidence/align-equivalence-15.json`, includes full EarlyVir) and
`tests/test_align_report.py` (option variants, per-column max |diff| on any
mismatch, `--timing` under the bench lock).

## Stage prefilter (Kmer-db 2.3.1 as driven by `vclust prefilter`)

Files: `prefilter.bend` (CLI, IO, batches), `pf_fasta.bend` (FASTA reader),
`pf_core.bend` (k-mer extraction, partitioning, grouping, pair counting,
filtering), `pf_sel.bend` (`--max-seqs`), `pf_num.bend` (64-bit and
fixed-point integer arithmetic). All pass `bend --check-only` with ALL PROOFS
CHECK; there is no `@unsafe` (no `Array.fork`/`Array.join`): parallel tasks
only receive data they own.

```bash
bend prefilter.bend -o prefilter
./prefilter -i in.fasta -o fltr.txt [-k 25] [--min-kmers 20] [--min-ident 0.7] \
  [--batch-size 0] [--kmers-fraction 1] [--max-seqs 0] +RTS --threads 12 -RTS
```

`-t N` is accepted and ignored by the binary; threads are the runtime's
`+RTS --threads N -RTS` (`run.py prefilter -t N` does that mapping).

### What is reproduced (from the Kmer-db 2.3.1 and vclust.py sources)

`vclust prefilter` runs `kmer-db build -multisample-fasta -k K -f F`,
`kmer-db all2all-sp -sparse -min num-kmers:N -min ani-shorter:T
[-sample-rows ani-shorter:M]` (or `all2all-parts` over `mfasta-tool split`
parts with `--batch-size`), then `kmer-db distance ani-shorter -sparse -min T`.

- Records: a record starts at every `>`; the name is the header up to the
  first space (a `\r` before `\n` dropped); `\n`/`\r` are removed from the
  sequence; A/C/G/T/U in either case are bases, every other byte breaks the
  k-mers covering it (`KmerHelper::extract`).
- k-mers: canonical = min(forward, reverse complement) as 2k-bit integers,
  deduplicated per sample; the per-sample unique count is `total-kmers`.
- `--kmers-fraction f < 1`: Kmer-db's `MinHashFilter` keeps a k-mer when
  `hash(x) < (uint64)((double)UINT64_MAX * f)`, with x widened to an 8-bit
  prefix for k < 20 (`(x << s) | (x & (2^s-1))`, s = 40 - 2k). The 64-bit
  Murmur-style hash and the threshold (decimal -> nearest binary64, ties to
  even -> times 2^64, truncated) are computed exactly on U32 words.
- Pairs: for every a < b, c = shared unique k-mers; kept when c >= min-kmers
  and ani-shorter >= T, ani-shorter = 1 + ln(2c / (c + m)) / k, m = the smaller
  of the two counts. Row b lists `a+1:value,` for a < b (1-based, ascending);
  the value is Kmer-db's `Double2PChar` (6 decimals, round half up).
- `--max-seqs M`: Kmer-db's `Sampler` (strategy best). Every kept pair is
  offered to both rows; each row keeps its M items of highest ani-shorter,
  ties to the smaller index (the heap's order), printed by index (so rows
  also contain a > b). The score is compared as the exact rational c/m.
- `--batch-size B`: same output as without it (all2all-parts concatenates
  part matrices); in Bend it bounds memory by processing rows in batches of
  B (every batch re-runs the k-mer passes; the dense count slab is B x n).
- Header: `kmer-length: K fraction: F ,name1,...,` with F printed as C++
  `operator<<(double)` (`%g`, 6 significant digits).
- Arithmetic: Bend has no F64. ln is computed with a 64-bit fixed-point
  atanh series (error < 1e-17), so the printed value can differ from the
  binary64 one only if the exact value is within ~1e-10 of a rounding
  boundary of the 6th decimal; none occurred in the tests. The min-ident
  comparison uses the decimal threshold floor(T * 2^64).

### Algorithm (scalable, fork-join, no shared arrays)

1. Read the FASTA (sequential IO, 1 MiB chunks) into one owned 2-bit packed
   array per record, split into valid-base segments.
2. Count pass (parallel over samples): extract every canonical k-mer, hash it
   (32-bit mix), count it in its bucket; there are P x Q buckets
   (P = passes = 2^ceil(log2(bases / 2^24)), Q = 64 groups).
3. For each pass p (sequential, bounds memory): every sample re-extracts its
   k-mers of pass p into Q exact-size arrays; the sample x group lists are
   transposed by re-linking owned arrays; each group (parallel) gathers its
   k-mers, counting-sorts them on more hash bits, insertion-sorts each small
   sub-bucket on the full key (stable, so samples stay ascending), scans runs
   of equal k-mers (deduplicating per sample, counting unique k-mers), and
   for every k-mer shared by distinct samples a < b emits the code
   T(b) + a (T(b) = b(b-1)/2), routed to the row block of b (R = 64 blocks of
   equal triangle area); row blocks (parallel) add their codes into their
   dense slab of the lower-triangular count matrix.
4. Final (parallel over row blocks): filter and format the rows; with
   `--max-seqs`, the kept pairs go through the per-row top-M selection.

Work is linear in k-mers x passes plus the (k-mer, sample pair) incidences,
like Kmer-db (no walk over non-sharing pairs). Memory: sequences (~0.4 B/base)
+ the n(n-1)/2 U32 count matrix (or B x n per batch) + one pass of k-mers.
Limits: n(n-1)/2 must fit in U32 per batch (n <= 92681 without
`--batch-size`), directories and gzip input are not supported.

### Equivalence (tests/test_prefilter.py)

`CAP=4G capped python3 tests/test_prefilter.py --full` compares the Bend
output with Vclust 1.3.1 byte for byte: **42/42 identical** (so max |diff| = 0)
on vclust_example, prefix1000, shortest1000 (each: defaults, `--max-seqs 50`,
`--kmers-fraction 0.2`, `--max-seqs 1`, `--batch-size 300`,
`--batch-size 300 --max-seqs 5`, `-k 15 --kmers-fraction 0.5`, `-k 16`,
`-k 19 --kmers-fraction 0.3 --min-kmers 3`, `--min-kmers 1 --min-ident 0`,
`--min-ident 0.95 --max-seqs 3`), stratified1000 (the first six) and the full
EarlyVir (10,021 genomes: defaults, `--max-seqs 50`, `--kmers-fraction 0.2`).
`-k 30` is excluded only because the reference Kmer-db did not finish on the
example within the timeout (see above); the Bend binary completes it.

### Performance (bench lock, this machine, 12 hw threads)

TIMINGS
